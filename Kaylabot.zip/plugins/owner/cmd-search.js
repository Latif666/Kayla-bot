import fs from 'fs';
import path from 'path';

let handler = async (m, { text, __dirname }) => {
    const foundFiles = findFilesWithCommand(__dirname, text);

    if (foundFiles.length > 0) {
        let response = `File untuk command '${text}' berada di:\n`;
        response += foundFiles.join('\n');
        m.reply(response);
    } else {
        m.reply(`Tidak ditemukan file untuk command '${text}'.`);
    }
}

handler.help = ['caricommand'];
handler.tags = ['mods'];
handler.command = /^(caricommand|cc|findcommand)$/i;

handler.mods = true;

export default handler;

function findFilesWithCommand(directory, command) {
    const foundFiles = [];
    const files = fs.readdirSync(directory);
    for (const file of files) {
        const filePath = path.join(directory, file);
        if (fs.lstatSync(filePath).isDirectory()) {
            foundFiles.push(...findFilesWithCommand(filePath, command));
        } else {
            const fileContent = fs.readFileSync(filePath, 'utf8');
            const lines = fileContent.split('\n');
            for (const line of lines) {
                if (line.includes('handler.command') && !line.trim().includes(':')) {
                    const commandArrayMatch = line.match(/\[(.+?)\]/);
                    if (commandArrayMatch) {
                        const commands = commandArrayMatch[1].split(',').map(cmd => cmd.trim().replace(/['"]/g, ''));
                        if (commands.includes(command)) {
                            // Menghapus direktori sebelum "plugins/"
                            const relativePath = filePath.split('plugins/').pop();
                            foundFiles.push(relativePath);
                            break; // Keluar dari loop jika sudah ditemukan
                        }
                    } else {
                        const commandRegex = /\/(.+?)\/i/;
                        const match = line.match(commandRegex);
                        if (match) {
                            const regex = new RegExp(match[1], 'i');
                            if (regex.test(command)) {
                                // Menghapus direktori sebelum "plugins/"
                                const relativePath = filePath.split('plugins/').pop();
                                foundFiles.push(relativePath);
                                break; // Keluar dari loop jika sudah ditemukan
                            }
                        }
                    }
                }
            }
        }
    }
    return foundFiles;
}
