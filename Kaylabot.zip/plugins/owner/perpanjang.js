import db from '../../lib/database.js'
let handler = async (m, { conn, args }) => {
    let groupId = m.chat; // ID grup yang ingin kamu perpanjang
    let chats = db.data.chats[groupId];
    
    if (chats) {
        if (chats.expired) {
            let additionalDays = parseInt(args[0]) || 0; // Jumlah hari tambahan untuk perpanjangan
            if (additionalDays > 0) {
                chats.expired += additionalDays * (24 * 60 * 60 * 1000); // Perpanjang waktu expired

                // Hitung sisa hari baru setelah perpanjangan
                let currentTime = +new Date();
                let remainingTime = Math.max(0, chats.expired - currentTime);
                let remainingDays = Math.ceil(remainingTime / (24 * 60 * 60 * 1000));

                m.reply(`Sisa hari kadaluwarsa dalam grup ini sekarang adalah ${remainingDays} hari.`);
            } else {
                m.reply("Masukkan jumlah hari tambahan yang valid.");
            }
        } else {
            m.reply("Grup ini tidak memiliki waktu kadaluwarsa yang ditetapkan.");
        }
    } else {
        m.reply("Grup ini belum pernah dijoin oleh bot.");
    }
}

handler.help = ['perpanjang <jumlah_hari>'];
handler.tags = ['owner'];
handler.command = /^(perpanjang)$/i;

handler.owner = true;

export default handler;