import fs from 'fs';
import path from 'path';

let handler = async (m, { conn, usedPrefix, command, text, __dirname }) => {
    if (!text) return m.reply(`Nama file nya apa?\n\nContoh: *${usedPrefix + command} sc*`);
    let filename = path.join(__dirname, /\.[a-zA-Z0-9]+$/.test(text) ? `./../${text}` : `./${text}.js`);
    let listPlugins = fs.readdirSync(path.join(__dirname)).map(v => v.replace(/\.js/, ''));

    if (!fs.existsSync(filename)) return m.reply(`'${filename}' tidak ditemukan!\n${listPlugins.map(v => v).join('\n').trim()}`);

    // Mengirim file dengan nama asli
    let mimeType = text.endsWith('.json') ? 'application/json' : 'application/javascript';
    let originalFilename = path.basename(filename);
    conn.sendMessage(m.chat, {
        document: fs.readFileSync(filename),
        fileName: originalFilename,
        mimetype: mimeType,
        fileLength: 900000000000,
        pageCount: '',
        caption: 'ini',
        contextInfo: {
            externalAdReply: {
                title: originalFilename,
                body: '',
                thumbnailUrl: 'https://telegra.ph/file/14f301e0dca1f63722d56.jpg', 
                sourceUrl: '',
                mediaType: 1,
                renderLargerThumbnail: true
            }
        }
    }, { quoted: m });
}

handler.help = ['getfile'];
handler.tags = ['mods'];
handler.command = /^(gf|getfile)$/i;
handler.mods = true;

export default handler;
