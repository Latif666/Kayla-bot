import fs from 'fs';
import path from 'path';

let handler = async (m, { usedPrefix: _p, __dirname, args, text, usedPrefix, plugins, command }) => {
    if (!text) return m.reply(`Contoh penggunaan: ${usedPrefix + command} plugin_name`);
    
    let pluginName = text.trim(); // Nama plugin yang akan dihapus

    if (!pluginName.endsWith('.js')) {
        // Jika nama plugin tidak berakhiran .js
        let pluginPath = path.join(__dirname, '../plugins', pluginName + '.js');

        if (fs.existsSync(pluginPath)) {
            // Hapus file plugin jika ada
            fs.unlinkSync(pluginPath);
            return m.reply(`Plugin "${pluginName}.js" berhasil dihapus.`);
        }
    } else {
        // Jika nama plugin berakhiran .js, cari di dalam folder plugins
        let pluginPath = path.join(__dirname, '../plugins', pluginName);

        if (fs.existsSync(pluginPath)) {
            // Hapus file plugin jika ada
            fs.unlinkSync(pluginPath);
            return m.reply(`Plugin "${pluginName}" berhasil dihapus.`);
        }
    }

    return m.reply(`Plugin "${pluginName}" tidak ditemukan.`);
}

handler.help = ['deleteplugin'];
handler.tags = ['owner'];
handler.command = /^(deleteplugin|df|dltplugin)$/i;

handler.mods = true;

export default handler;
