import db from '../../lib/database.js'
let handler = async (m, { conn }) => {
    let groupId = m.chat; // ID grup yang ingin kamu periksa
    let chats = db.data.chats[groupId];
    
    if (chats) {
        if (chats.expired) {
            let currentTime = +new Date();
            let remainingTime = Math.max(0, chats.expired - currentTime);
            let remainingDays = Math.ceil(remainingTime / (24 * 60 * 60 * 1000)); // Hitung hari yang tersisa

            if (remainingDays > 0) {
                m.reply(`Sisa hari sebelum expired dalam grup ini: ${remainingDays} hari.`);
            } else {
                m.reply("Grup ini sudah kadaluwarsa.");
            }
        } else {
            m.reply("Grup ini tidak memiliki waktu kadaluwarsa yang ditetapkan.");
        }
    } else {
        m.reply("Grup ini belum pernah dijoin oleh bot.");
    }
}

handler.help = ['cekexpire'];
handler.tags = ['owner'];
handler.command = /^(cekexpire)$/i;

handler.owner = true;

export default handler