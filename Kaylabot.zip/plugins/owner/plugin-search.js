import similarity from 'similarity'
import fs from 'fs'
import path from 'path'

let handler = async (m, { usedPrefix, command, text, __dirname }) => {
    if (!text) return m.reply(`Apa yang ingin Anda cari?\n\nContoh: *${usedPrefix + command} tiktok.js*`);

    const filePath = findFileInDirectory(__dirname, text);

    if (filePath) {
        m.reply(`"${text}" berada di\n/${filePath}`);
    } else {
        const similarFile = findSimilarFileInDirectory(__dirname, text);
        if (similarFile) {
            m.reply(`Apakah yang Anda maksud "${similarFile}"?`);
        } else {
            m.reply(`File "${text}" tidak ditemukan.`);
        }
    }
}

handler.help = ['cariplugin']
handler.tags = ['mods']
handler.command = /^(cariplugin|cp|findplugin)$/i

handler.mods = true

export default handler;

function findFileInDirectory(directory, filename) {
    const files = fs.readdirSync(directory);
    for (const file of files) {
        const filePath = path.join(directory, file);
        if (fs.lstatSync(filePath).isDirectory()) {
            const foundFile = findFileInDirectory(filePath, filename);
            if (foundFile) {
                return path.join(file, foundFile);
            }
        } else {
            if (filename.toLowerCase() === path.basename(filePath).toLowerCase()) {
                return file;
            }
        }
    }
    return null;
}

function findSimilarFileInDirectory(directory, filename) {
    const files = fs.readdirSync(directory);
    for (const file of files) {
        const filePath = path.join(directory, file);
        if (fs.lstatSync(filePath).isDirectory()) {
            const foundFile = findSimilarFileInDirectory(filePath, filename);
            if (foundFile) {
                return path.join(file, foundFile);
            }
        } else {
            if (similarity(file, filename) > 0.8) {
                return file;
            }
        }
    }
    return null;
}
