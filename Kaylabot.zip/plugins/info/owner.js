let handler = async (m, { conn, command, usedPrefix}) => {
	const data = [...db.data.datas.rowner.filter(([id, isCreator]) => id && isCreator), ...db.data.datas.owner.filter(([id, isCreator]) => id && isCreator)]
	if (data.length == 0) throw `*[ ! ] Real Owner belum di set.*\n\n*${usedPrefix}addrealowner* untuk menambahkan Owner Asli.\n\n*${usedPrefix}addowner* untuk menambahkan Owner Biasa.`
 await conn.sendContact(m.chat, data.map(([id, name]) => [id, name]), m,{
 contextInfo: { 
 externalAdReply: { 
 title: '𝙆𝙡𝙞𝙠 𝙜𝙖𝙢𝙗𝙖𝙧 👆🏿', 
 body: '𝙐𝙣𝙩𝙪𝙠 𝙈𝙚𝙣𝙜𝙝𝙪𝙗𝙪𝙣𝙜𝙞 𝙊𝙬𝙣𝙚𝙧', 
 sourceUrl: `https://wa.me//${mods}`,
 thumbnail: '',
 thumbnailUrl: 'https://telegra.ph/file/8ac63b3e91ba8bc20c70f.jpg', 
 mediaType: 1,
 showAdAttribution: true, 
 renderLargerThumbnail: true 
 }
   }
     },
       {
         quoted: m,
         ephemeralExpiration: ephemeral
           }
             );
}

handler.help = ['owner']
handler.tags = ['group']
handler.command = /^(owner|creator)$/i

export default handler