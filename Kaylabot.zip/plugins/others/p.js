let handler = async (m, { conn, _argh, text, usedPrefix, command }) => {
if (!m.text.includes('p'){return}
    
await m.reply(`Gapunya Agama Ya?`)
}

handler.customPrefix = /^(p)$/i
handler.command = new RegExp
export default handler