import db from '../../lib/database.js'
import { plugins } from '../../lib/plugins.js'
import loadingt from '../_functionbefore/loading.js'
import { readMore, ranNumb, padLead, runtimes } from '../../lib/func.js'
import { promises } from 'fs'
import { join } from 'path'
import os from 'os'

let Defaulttags = {
    'info':'*INFO*', 
    'quotes':'*QUOTES*',
	'searching': ' *SEARCHING*',
    'sound' :'*SOUND*',
	'search': 'SEARCHING',
	'information': ' *INFORMATION*',
	'entertainment': ' *ENTERTAINMENT*',
	'primbon': ' *PRIMBON*',
	'creator': ' *CREATOR*',
	'tools': ' *TOOLS MENU*',
	'textpro': '*Make Text Effect*',
	'oxy': '*Make Photo Effect*',
	'owner': '🌸 *Owner*',
	'ownerr': '🌺 *Real Owner*',
	'mods': '💮 *DEV / MODS*',
	'nsfw': '*BOKEP*',
	'rpg': '🎮 *RPG*',
	'game': '🎮 *GAMES*',
	'funanonim': '🎩 *ANONYMOUS*',
	'funkerang': '🐚 *KERANG AJAIB*',
	'group': '*Some Admin Privilages*',
	'searchphoto': '*Photo Effects*',
	'searcheditor': '*Photo Effects*',
	'filter': '*Photo Filters*',
	'downloader': '*Supported Media*',
	'anime': ' *RANDOM ANIME*',
	'genshin': '*Genshin Data*',
	'fun' : '*FUN MENU*',
	'ai': '*Artificial Intelligence*',
	'internet': '*INTERNET*',
	'islamic': '*ISLAM MENU*',
}
let tags = {}
let ulangtahun = hitungmundur(20, 12, 2023);
const petik = '*'
const defaultMenu = {
	before: `
𝙃𝙖𝙡𝙡𝙤 %name!
%readmore
┏  *🄺.🄰.🄸.🄻.🄰*  ┓
┃╭─────────────┛
┃├↬ *.owner* 
┃├↬ *.info* 
┃├↬ *.levelup* 
┃├↬ *.Runtime* : *%uptime*
┃├↬ *.OS Uptime* : *%osuptime*
┃╰─────────────┓
┗═━═━═━═━═━═━═━┛
*Hitung Mundur Ultah Kayla*
${ulangtahun}

╭「 *%name!* 」
┃↬ Role : *%role*
┃↬ Limit : *%limit*
╰═━═━═━═━═━═━═\n🄿 = khusus user premium\n🄻 = dibatasi penggunaan nya setiap user\n`.trimStart(),
	header: `┏「 %category 」┓\n┃╭────────⊸`,
	body: `┃├ _%cmd_ %isPremium %islimit`,
	footer: `┗╰────────⊸\n`,
}
let handler = async (m, { conn, usedPrefix: _p, __dirname,args,command, isPrems}) => {
global.loading = loadingt(conn, m)
let commandNya = (/^(.*?(menu|list|help).*?)$/i.exec(args[0] || '') || [])[1];
let listnya = (command.replace(/menu|list|help/gi, '') || (args[0] || '').toLowerCase());
function replacePlaceholders(text, replace) {
  return text.replace(/%\w+/g, match => {
    const key = match.slice(1);
    return replace[key] || match;
  });
}

    
 	try {
		let meh = padLead(ranNumb(43), 3)
		let nais = await (await fetch('https://raw.githubusercontent.com/clicknetcafe/Databasee/main/azamibot/menus.json')).json().then(v => v.getRandom())
		let _package = JSON.parse(await promises.readFile(join(__dirname, '../package.json')).catch(_ => ({}))) || {}
		let { limit, role } = db.data.users[m.sender]
		let name = await conn.getName(m.sender).replaceAll('\n','')
		let uptime = runtimes(process.uptime())
		let osuptime = runtimes(os.uptime())
		let help = Object.values(plugins).filter(plugin => !plugin.disabled).map(plugin => {
			return {
				help: Array.isArray(plugin.tags) ? plugin.help : [plugin.help],
				tags: Array.isArray(plugin.tags) ? plugin.tags : [plugin.tags],
				prefix: 'customPrefix' in plugin,
				limit: plugin.limit,
				premium: plugin.premium,
				enabled: !plugin.disabled,
			}
        })
		await loading
      if (!listnya) { tags = Defaulttags }
      const allCategories = Object.keys(tags).map(category => `┃├ _${_p}${command} ${category}_`).join('\n');
		      
		if (!listnya) {
      const menuText = replacePlaceholders(defaultMenu.before + `\n*Ketik* *${_p}${command} all/semua*\n_${_p}${command} all_\n_${_p}${command} semua_\n_untuk melihat semua list menu_\n┏「 *LIST MENU* 」┓\n┃╭─────────⊸\n` + allCategories + `\n┗╰─────────⊸`, {
        limit: isPrems ? 'Infinity' : limit,
        name,
        role,
        uptime,
        osuptime,
        readmore: readMore,
      });
      await conn.sendFThumb(m.chat, db.data.datas.maingroupname, menuText, nais, db.data.datas.linkgc, freply);
      return;
}
	switch (listnya) {	
case 'info':
tags = {'info':'*INFO*'}
break;               
case 'sound':
tags = {'sound':'*SOUNDS*'}
break;
case 'quotes':
tags = {'quotes':'*QUOTES*'}
break;
case 'searching':
tags = {'searching': ' *SEARCHING*'};
break;
case 'search':
tags = {'search': '*SEARCHING*'};
break;
case 'information':
tags = {'information': ' *INFORMATION*'};
break;
case 'entertainment':
tags = {'entertainment': ' *ENTERTAINMENT*'};
break;
case 'primbon':
tags = {'primbon': ' *PRIMBON*'};
break;
case 'creator':
tags = {'creator': ' *CREATOR*'};
break;
case 'tools':
tags = {'tools': ' *TOOLS MENU*'};
break;
case 'textpro':
tags = {'textpro': '*Make Text Effect*'};
break;
case 'oxy':
tags = {'oxy': '*Make Photo Effect*'};
break;
case 'owner':
tags = {'owner': '🌸 *Owner*'};
break;
case 'ownerr':
tags = {'ownerr': '🌺 *Real Owner*'};
break;
case 'mods':
tags = {'mods': '💮 *DEV / MODS*'};
break;
case 'bokep': case 'nsfw':
tags = {'nsfw': ' *BOKEP*'};
break;
case 'funrpg': case 'rpg':
tags = {'rpg': '🎮 *RPG*'};
break;
case 'game':
tags = {'fungame': '🎮 *GAMES*'};
break;
case 'funanonim':
tags = {'funanonim': '🎩 *ANONYMOUS*'};
break;
case 'funkerang':
tags = {'funkerang': '🐚 *KERANG AJAIB*'};
break;
case 'group':
tags = {'group': '*Some Admin Privilages*'};
break;
case 'searchphoto':
tags = {'searchphoto': '*Photo Effects*'};
break;
case 'searcheditor':
tags = {'searcheditor': '*Photo Effects*'};
break;
case 'filter':
tags = {'filter': '*Photo Filters*'};
break;
case 'downloader':
tags = {'downloader': '*Supported Media*'};
break;
case 'anime':
tags = {'anime': ' *RANDOM ANIME*'};
break;
case 'genshin':
tags = {'genshin': '*Genshin Data*'};
break;
case 'fun':
tags = {'fun': '*FUN MENU*'};
break;
case 'ai':
tags = {'ai': '*Artificial Intelligence*'}
break;
case 'internet':
tags = {'internet': '*INTERNET*'}
break;
case 'islam': case 'islamic':
tags = {'islamic': '*ISLAM MENU*'}
break;
case 'all': case 'semua':
tags = Defaulttags
break;
  default:
 let Cmd = command.replace(listnya, '')
 newReply(`Ga ada *${command} ${listnya}*`, true)
 return;  
  // Case default jika perintah tidak cocok
    break;
}
		let groups = {}
    for (let tag in tags) {
      groups[tag] = []
      for (let plugin of help)
        if (plugin.tags && plugin.tags.includes(tag))
          if (plugin.help) groups[tag].push(plugin)
    }
		conn.menu = conn.menu ? conn.menu : {}
		let before = conn.menu.before || defaultMenu.before
		let header = conn.menu.header || defaultMenu.header
		let body = conn.menu.body || defaultMenu.body
		let footer = conn.menu.footer || defaultMenu.footer
		let _text = [
			before.replace(': *%limit', `${isPrems ? ': *Infinity' : ': *%limit'}`),
			...Object.keys(tags).map(tag => {
				return header.replace(/%category/g, tags[tag]) + '\n' + [
					...help.filter(menu => menu.tags && menu.tags.includes(tag) && menu.help).map(menu => {
						return menu.help.map(help => {
							return body.replace(/%cmd/g, menu.prefix ? help : '%p' + help)
								.replace(/%islimit/g, menu.limit ? '' : '')
								.replace(/%isPremium/g, menu.premium ? '*🄿*' : '')
								.trim()
						}).join('\n')
					}),
					footer
				].join('\n')
			}),
		].join('\n')
		let text = typeof conn.menu == 'string' ? conn.menu : typeof conn.menu == 'object' ? _text : ''
		let replace = {
			'%': '%',
			p: _p, uptime, osuptime,
			me: conn.getName(conn.user.jid),
			github: _package.homepage ? _package.homepage.url || _package.homepage : '[unknown github url]',
			limit, name, role,
			readmore: readMore
		}
		text = text.replace(new RegExp(`%(${Object.keys(replace).sort((a, b) => b.length - a.length).join`|`})`, 'g'), (_, name) => '' + replace[name])
        console.log(`Command: ${command}, List: ${listnya}`);
		await conn.sendFThumb(m.chat, db.data.datas.maingroupname, text.trim(), nais, db.data.datas.linkgc, freply)
	} catch (e) {
		throw e
	}
}
handler.command = /^(.*?(menu|list|help).*?)$/i;


handler.exp = 3

export default handler



//functionhitungmundur
function hitungmundur(tanggal, bulan, tahun){
let from = new Date(`${bulan} ${tanggal}, ${tahun} 00:00:00`).getTime();
let now = Date.now();
let distance = from - now;
let days = Math.floor(distance / (1000 * 60 * 60 * 24));
let hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
let minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
let seconds = Math.floor((distance % (1000 * 60)) / 1000);
return days + ' Hari ' + hours + ' Jam ' + minutes + ' Menit ' + seconds + ' Detik'
}