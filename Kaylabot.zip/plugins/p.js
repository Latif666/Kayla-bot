import { createCanvas, registerFont, loadImage } from 'canvas';
import fs from 'fs';
import { sticker } from '../lib/sticker.js';

// Menggunakan font yang diinginkan
registerFont('src/font/212BabyGirl.otf', { family: '212BabyGirl' });

let handler = async (m, { text, conn }) => {
  // Ukuran dan pembuatan kanvas
  const canvas = createCanvas(1000, 1000);
  const context = canvas.getContext('2d');

  // Menggambar teks dengan background
  context.textAlign = 'center';
  context.textBaseline = 'middle';

  // Menghitung jumlah baris teks
  const lines = text.split('\n');
  const numLines = lines.length;

  // Ukuran font yang dinamis
  let fontSize = 400;
  do {
    context.font = `${fontSize}px 212BabyGirl`;
    fontSize--;
  } while (
    (context.measureText(text).width + context.measureText(m.name).width) > canvas.width - 20 ||
    getTextHeight(lines, context) > canvas.height - 20
  );

  // Menempatkan teks ke tengah
  const offsetY = (canvas.height - getTextHeight(lines, context)) / 2;

  // Ukuran lingkaran dan foto profil ikut mengecil
  const ppSize = 60 + fontSize / 7; // Ukuran lingkaran dan foto profil sesuai dengan ukuran teks
  let pp = await loadImage(await conn.profilePictureUrl(m.sender).catch(_ => 'https://i.ibb.co/3Fh9V6p/avatar-contact.png'));

  // Menggambar background teks dan nama pengguna
  const totalWidth = context.measureText(text).width + context.measureText(m.name).width + 40; // Menambah padding
  const textHeight = getTextHeight(lines, context) + 40; // Menambah padding
  context.fillStyle = 'rgba(255, 255, 255, 0.7)'; // Warna latar belakang dengan opacity
  context.fillRect((canvas.width - totalWidth) / 2, offsetY - textHeight / 2, totalWidth, textHeight);

  // Menggambar teks dengan border hitam dan teks putih
  context.lineWidth = 20;
  context.strokeStyle = 'black';
  context.fillStyle = 'white';

  lines.forEach((line, index) => {
    const y = offsetY + (index + 0.5) * fontSize;
    context.strokeText(line, canvas.width / 2, y);
    context.fillText(line, canvas.width / 2, y);
  });

  // Menambahkan nama pengguna di atas teks
  const username = m.name;
  const usernameFontSize = 80; // Ukuran font nama pengguna
  context.font = `${usernameFontSize}px Arial`;
  const usernameWidth = context.measureText(username).width;
  const usernameHeight = usernameFontSize + 20; // Menambah padding
  context.fillStyle = 'rgba(255, 0, 0, 0.7)'; // Warna latar belakang nama pengguna dengan opacity
  context.fillRect((canvas.width - totalWidth) / 2 + context.measureText(text).width, offsetY - textHeight / 2 - usernameHeight, usernameWidth, usernameHeight);
  context.fillStyle = 'black'; // Warna teks nama pengguna
  context.fillText(username, (canvas.width + totalWidth) / 2, offsetY - textHeight / 2 - usernameHeight / 2);

  // Simpan gambar
  context.save(); // Simpan konteks gambar
  context.beginPath();
  context.arc((canvas.width - ppSize) / 2, offsetY, ppSize / 2, 0, 2 * Math.PI); // Koordinat dan radius lingkaran
  context.closePath();
  context.clip(); // Gunakan lingkaran sebagai klip
  context.drawImage(pp, (canvas.width - ppSize) / 2 - ppSize / 2, offsetY - ppSize / 2, ppSize, ppSize); // Gambar foto profil dalam lingkaran
  context.restore(); // Pulihkan konteks gambar

  const buffer = canvas.toBuffer('image/png');
  let stiker = await sticker(buffer, false, global.packname, global.author);
  if (stiker) return conn.sendFile(m.chat, stiker, 'output.png', '', m);
  newReply('Gambar berhasil dibuat!');
};

handler.help = ['textstick3'];
handler.tags = ['sticker', 'creator'];
handler.command = /^(p)$/i;

export default handler;

// Fungsi untuk menghitung tinggi teks
function getTextHeight(lines, context) {
  const totalHeight = lines.length * parseInt(context.font);
  const totalSpacing = Math.max(0, lines.length - 1) * 10; // Spasi antar baris
  return totalHeight + totalSpacing;
}