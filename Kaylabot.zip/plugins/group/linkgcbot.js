import db from '../../lib/database.js'

let handler = async (m, { conn, command }) => {
	await conn.reply(m.chat, `*[ LINK GRUP BOT ]*\n\n${db.data.datas.linkgc}` || '[ ! ] Link GC belum di set oleh Owner.', m)
}

handler.help = ['linkgcbot']
handler.tags = ['group']
handler.command = /^((link)?(gc|gro?up)bot)$/i

export default handler