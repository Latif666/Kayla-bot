let handler = async(m, { conn,command,isAdmin,isBotAdmin, text}) => {
let chat = db.data.chats[m.chat]    
if (/add/.test(command)) {
 if (!isAdmin) {
				global.dfail('admin', m, conn)
				throw false
			} 
if (!isBotAdmin) {
				global.dfail('botAdmin', m, conn)
				throw false
} 
  if (!text) return newReply('Silakan masukkan kata yang ingin ditambahkan ke dalam database toksik.\n\nContoh: \naddtoxic Kontol');
  let kataToksik = text.toLowerCase();
  if (!chat.toxic.includes(kataToksik)) {
    chat.toxic.push(kataToksik);
    newReply(`Kata '${kataToksik}' berhasil ditambahkan ke dalam database kata toksik.`);
  } else {
    newReply(`Kata '${kataToksik}' sudah ada dalam database kata toksik.`);
  }
}
if (/del/.test(command)){
  if (!isAdmin) {
				global.dfail('admin', m, conn)
				throw false
			} 
if (!isBotAdmin) {
				global.dfail('botAdmin', m, conn)
				throw false
}
  if (!text) return newReply('Silakan masukkan kata yang ingin dihapus dari database toksik.\n\nContoh:\.deltoxic asu');
  let kataToksik = text.toLowerCase();
  if (chat.toxic.includes(kataToksik)) {
    chat.toxic = chat.toxic.filter(kata => kata !== kataToksik);
    newReply(`Kata '${kataToksik}' berhasil dihapus dari database kata toksik.`);
  } else {
    newReply(`Kata '${kataToksik}' tidak ditemukan dalam database kata toksik.`);
  }
}
if (/list/.test(command)){
    if (!isAdmin) {
				global.dfail('admin', m, conn)
				throw false
			} 
if (!isBotAdmin) {
				global.dfail('botAdmin', m, conn)
				throw false
};
  let badWordsList = chat.toxic.join('\n=> ');

  if (badWordsList) {
    newReply(`List kata kasar:\n\n=> ${badWordsList}`);
  } else {
    newReply('List kata kasar masih kosong.');
  }
};
}
handler.help = ['addtoxic', 'deltoxic']
handler.tags = ['group']
handler.command = /^((add|list|del)(toxic|badword|toksik))$/i
export default handler



export async function before(m, { isAdmin, isBotAdmin }) {
      if (m.isBaileys && m.fromMe)
        return !0
    if (!m.isGroup) return !1
  let chat = db.data.chats[m.chat];
  let toxic = chat.toxic.some(word => m.text.toLowerCase().includes(word));
  if (chat.antiToxic && toxic) {
      this.sendMessage(m.chat, { delete: { remoteJid: m.chat, fromMe: false, id: m.key.id, participant: m.key.participant }})
   newReply('Jangan pakai kata kasar, ya! 😊');
  }

  return !0;
}
