import { createCanvas, registerFont } from 'canvas';
import fs from 'fs/promises';
import { createFFmpeg, fetchFile, run } from 'ffmpeg';

// Menggunakan font yang diinginkan
registerFont('src/font/212BabyGirl.otf', { family: '212BabyGirl' });

let handler = async (m, { conn }) => {
  const canvas = createCanvas(1000, 1000);
  const context = canvas.getContext('2d');

  // Menggambar teks berwarna merah
  context.fillStyle = 'red';
  context.fillRect(0, 0, canvas.width / 3, canvas.height);
  context.font = '400px 212BabyGirl';
  context.fillStyle = 'white';
  context.textAlign = 'center';
  context.textBaseline = 'middle';
  context.fillText('Red', canvas.width / 6, canvas.height / 2);

  // Menggambar teks berwarna hijau
  context.fillStyle = 'green';
  context.fillRect(canvas.width / 3, 0, canvas.width / 3, canvas.height);
  context.fillStyle = 'white';
  context.fillText('Green', canvas.width / 2, canvas.height / 2);

  // Menggambar teks berwarna biru
  context.fillStyle = 'blue';
  context.fillRect((2 * canvas.width) / 3, 0, canvas.width / 3, canvas.height);
  context.fillStyle = 'white';
  context.fillText('Blue', (5 * canvas.width) / 6, canvas.height / 2);

  // Simpan frame sebagai gambar
  const buffer = canvas.toBuffer('image/png');
  const framePath = 'frame.png';
  await fs.writeFile(framePath, buffer);

  // Mengonversi gambar menjadi video dengan efek berkedip
  const ffmpeg = createFFmpeg({ log: true });
  await ffmpeg.load();
  ffmpeg.FS('writeFile', framePath, await fetchFile(framePath));
  await run(
    ffmpeg,
    '-t', '3', // Durasi video 3 detik
    '-i', framePath,
    '-vf', 'scale=trunc(iw/2)*2:trunc(ih/2)*2',
    '-vf', 'fps=10', // Frame rate 10 fps
    '-y', 'output.mp4'
  );

  // Mengirimkan sticker video
  let stiker = await sticker(ffmpeg.FS('readFile', 'output.mp4'), true, global.packname, global.author);
  if (stiker) return conn.sendFile(m.chat, stiker, 'output.webp', '', m);
  newReply('Sticker video berhasil dibuat!');
};

handler.help = ['tesvideo'];
handler.tags = ['sticker'];
handler.command = /^(l)$/i;

export default handler;


// Fungsi untuk menghitung tinggi teks
function getTextHeight(lines, context) {
  const totalHeight = lines.length * parseInt(context.font);
  const totalSpacing = Math.max(0, lines.length - 1) * 10; // Spasi antar baris
  return totalHeight + totalSpacing;
}