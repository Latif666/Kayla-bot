let handler = async (m, { text, conn,command}) => {
	if (!text) throw 'Perihal Apah';
	var body = text.replace(/\s+/g, '+')
	try {
		var xzn
		switch (command) {
			case 'tttren':
				xzn = await fetch(API('xzn', 'api/tttrending', {
					region: body
				}, 'apikey'))
				break;
			case 'asupantt':
				xzn = await fetch(API('xzn', 'api/ttsearch', {
					search: body
				}, 'apikey'))
				break;
		}
		var wtf = await xzn.json()
		conn.sendFile(m.chat, wtf.play, '', wtf.title, m)
	} catch (e) {
		throw e.toString();
	};
};
handler.help = ['tttren','asupantt']
handler.command = ['tttren', 'asupantt'];
handler.tags = ['tiktok', 'downloader'];

export default handler;
/*var [t1, t2] = body.split`|`
	if (!/[0-9]/.test(t2)) throw ('only number')*/