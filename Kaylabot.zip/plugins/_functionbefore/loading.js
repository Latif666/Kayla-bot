const loadingt = async (conn, m) => {
     const emojis = ['🕛','🕑','🕓','🕕','🕗','🕙','✅'];
    for (const emoji of emojis) {
        await conn.sendMessage(m.chat, {
            react: {
                text: emoji,
                key: m.key,
            }
        });
        await new Promise(resolve => setTimeout(resolve, 100)); // Menggunakan jeda 100 milidetik (0.1 detik)
    }
}

export default loadingt;