import fs from 'fs'
let handler = m => m
handler.all = async function (m) {
let botname = db.data.datas.author
let wagc = db.data.datas.linkgc
global.newReply = (text, option) => {
this.sendMessage(m.chat, { 
text: text,
contextInfo:{
forwardingScore: 9999999,
isForwarded: true, 
mentionedJid:[m.sender],
"externalAdReply": {
"showAdAttribution": true,
"renderLargerThumbnail": option || false,
"title": botname, 
"containsAutoReply": true,
"mediaType": 1, 
"thumbnail": fs.readFileSync("./media/thumbnail.jpg"),
"mediaUrl": `${wagc}`,
"sourceUrl": `${wagc}`
}
}
}, { quoted: m })
           }}

export default handler;