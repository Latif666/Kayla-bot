import fs from 'fs';
import fetch from 'node-fetch';
import { sticker, sticker3, addExif, video2webp } from '../../lib/sticker.js';
import { isUrl } from '../../lib/func.js';

let handler = async (m, { conn, text, usedPrefix, command }) => {
    let c = command;
    let wm = 'kaila';
    global.fkontak = { key: { fromMe: false, participant: `0@s.whatsapp.net`, ...(m.chat ? { remoteJid: `status@broadcast` } : {}) }, message: { 'contactMessage': { 'displayName': wm, 'vcard': `BEGIN:VCARD\nVERSION:3.0\nN:XL;${wm},;;;\nFN:${wm},\nitem1.TEL;waid=${m.sender.split('@')[0]}:${m.sender.split('@')[0]}\nitem1.X-ABLabell:Ponsel\nEND:VCARD`, 'jpegThumbnail': fs.readFileSync('./media/thumbnail.jpg'), thumbnail: fs.readFileSync('./media/thumbnail.jpg'),sendEphemeral: true}}};
    let who = m.mentionedJid && m.mentionedJid[0] ? m.mentionedJid[0] : m.fromMe ? conn.user.jid : m.sender;
    let pp = await conn.profilePictureUrl(who).catch(_ => 'https://telegra.ph/file/05abede3a863613f147e0.jpg');
    let name = await conn.getName(who);




        if (isUrl(text)) {
            let s = await sticker(false, text, packname, author);
            conn.sendFile(m.chat, s, 'sticker.webp', '', m, null, { fileLength: 100, contextInfo: {
                externalAdReply: {
                    showAdAttribution: true,
                    mediaUrl: '',
                    mediaType: 2,
                    description: 'KAYLA',
                    title: `stiker nya kak`,
                    body: 'LATIF',
                    thumbnail: await (await fetch(pp)).buffer(),
                    sourceUrl: ''
                }
            }});
        } else {
            let buffer, q = m.quoted ? m.quoted : m;
            let mime = (q.msg || q).mimetype || q.mediaType || '';
            let fps = command.replace(/\D/g, '');

            if (/image|video/g.test(mime)) {
                let ch, img = await q.download?.();

                if (/video/g.test(mime)) {
                    if ((q.msg || q).seconds > 30) return m.reply('Maksimal 10 detik!');
                    ch = (q.gifPlayback || q.message?.videoMessage?.gifPlayback) ? 1 : 2;
                } else ch = 0;

                if (ch > 0) buffer = await (/webp/g.test(mime) ? addExif(img, packname, author) : ch > 1 ? addExif(await video2webp(img, isNaN(fps) ? 15 : fps), packname, author) : sticker(img, false, packname, author));
                else {
                    try { buffer = await addExif(await sticker3(img, false), packname, author); }
                    catch { buffer = await sticker(img, false, packname, author); }
                }

                conn.sendFile(m.chat, buffer, 'sticker.webp', '', m, null, { fileLength: 100, contextInfo: {
                    externalAdReply: {
                        showAdAttribution: true,
                        mediaUrl: '',
                        mediaType: 2,
                        description: 'KAYLA',
                        title: `STICKER`,
                        body: 'LATIF',
                        thumbnail: await (await fetch(pp)).buffer(),
                        sourceUrl: ''
                    }
                }});
            } else return m.reply(`Kirim Gambar/Video Dengan Caption *${usedPrefix + c}*\nDurasi Video 1-9 Detik`);
        }
    } 





handler.help = ['', '30fps', '45fps', '60fps'].map(v => 'sticker' + v);
handler.tags = ['creator'];
handler.command = /^(s(tic?ker)?(gif)?(30|45|60)?(fps)?)$/i;

export default handler;