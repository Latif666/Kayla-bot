import { createCanvas, registerFont, loadImage } from 'canvas';
import fs from 'fs';
import { sticker } from '../../lib/sticker.js';

let handler = async (m, { conn, text }) => {
  registerFont('src/font/Edoms-Handwritting-Normal.ttf', { family: 'Edoms-Handwritting-Normal' });
let username = m.name;
  // Hitung lebar dan tinggi balon pesan sesuai dengan panjang teks dan jumlah baris
  const { width: textWidth, height: textHeight, lines } = getTextDimensions(text, '350px Edoms-Handwritting-Normal');
  const { width: nameWidth, height: nameHeight } = getUsernameDimensions(username, `bold 350px Arial`); 
  let jumlh  = nameWidth + textWidth 
  let jumlah = nameHeight + textHeight 
 const canvas = createCanvas(Math.min(jumlh / 3.70 + 10, 3100), jumlah + 100 );
const context = canvas.getContext('2d');


 

const backgroundColor = generateRandomColor();
const textColor = getContrastColor(backgroundColor);
  // Warna latar belakang
  context.fillStyle = backgroundColor;

  // Menggambar balon dengan sudut yang lebih lebar dan kurang tajam
  drawRoundedRect(context, 120.90, 50, (jumlh / 5.10 + 20),jumlah , 100);
    

  // Tambahkan foto profil pengguna di sebelah kiri
  // Tambahkan foto profil pengguna di sebelah kiri dalam bentuk lingkaran
let pp = await loadImage(await conn.profilePictureUrl(m.sender).catch(_ => 'https://i.ibb.co/3Fh9V6p/avatar-contact.png'));
context.save(); // Simpan konteks gambar
context.beginPath();
context.arc(60, 110, 50, 0, 2 * Math.PI); // Koordinat dan radius lingkaran
context.closePath();
context.clip(); // Gunakan lingkaran sebagai klip
context.drawImage(pp, 5, 30, 115, 130); // Gambar foto profil dalam lingkaran
context.restore(); // Pulihkan konteks gambar
    
  // Pengaturan teks
  context.font = '90px Edoms-Handwritting-Normal';
  context.fillStyle = textColor;
  context.textAlign = 'left'; // Mengatur teks ke sebelah kiri
  context.textBaseline = 'middle';

  // Menyusun teks di tengah kanvas
  lines.forEach((line, index) => {
    const y = canvas.height / 2 + (index - (lines.length - 1) / 2) * textHeight / lines.length;
    const x = 172; // Padding dari sisi kiri
    context.fillText(line, x, y);
  });
    context.font = `bold 70px Arial`;
context.fillStyle = generateRandomColor(); // Warna kontras dan warni

context.fillText(username, 170, 120);
  // Simpan gambar
  const buffer = canvas.toBuffer('image/png');
  let stiker = await sticker(buffer, false, global.packname, global.author);
  if (stiker) return conn.sendFile(m.chat, stiker, 'output.png', '', m);
  newReply('Gambar berhasil dibuat!');
};

handler.help = ['tes'];
handler.tags = ['sticker'];
handler.command = /^(qc)$/i;

export default handler;

// Panggil fungsi dengan teks, warna latar belakang, dan warna teks yang diinginkan
function generateRandomColor() {
  const characters = '0123456789ABCDEF';
  let color = '#';
  for (let i = 0; i < 6; i++) {
    color += characters[Math.floor(Math.random() * 16)];
  }
  return color;
}

// Fungsi untuk menggambar balon dengan sudut yang lebih lebar dan kurang tajam
function drawRoundedRect(context, x, y, width, height, radius) {
  context.beginPath();
  context.moveTo(x + radius, y);
  context.arcTo(x + width, y, x + width, y + height, radius);
  context.arcTo(x + width, y + height, x, y + height, radius);
  context.arcTo(x, y + height, x, y, radius);
  context.arcTo(x, y, x + width, y, radius);
  context.closePath();
  context.fill();
}

// Fungsi untuk menghitung dimensi teks, termasuk jumlah baris
function getTextDimensions(text, font) {
  const canvas = createCanvas(1, 1);
  const context = canvas.getContext('2d');
  context.font = font;

  const lines = text.split('\n');
  const textWidth = Math.max(...lines.map(line => context.measureText(line).width));
  const textHeight = context.measureText('M').actualBoundingBoxAscent + context.measureText('M').actualBoundingBoxDescent;

  return { width: textWidth, height: textHeight * lines.length, lines };
}
// Fungsi untuk menghitung lebar dan tinggi nama pengguna
function getUsernameDimensions(username, font) {
  const canvas = createCanvas(1, 1);
  const context = canvas.getContext('2d');
  context.font = font;

  const usernameWidth = context.measureText(username).width;
  const usernameHeight = context.measureText('M').actualBoundingBoxAscent + context.measureText('M').actualBoundingBoxDescent;

  return { width: usernameWidth, height: usernameHeight };
}


function getContrastColor(hexColor) {
  // Ambil nilai RGB dari warna latar belakang
  const r = parseInt(hexColor.slice(1, 3), 16);
  const g = parseInt(hexColor.slice(3, 5), 16);
  const b = parseInt(hexColor.slice(5, 7), 16);

  // Hitung nilai kecerahan berdasarkan formula
  const brightness = (r * 299 + g * 587 + b * 114) / 1000;

  // Tentukan warna teks berdasarkan kecerahan
  return brightness > 128 ? '#000000' : '#FFFFFF'; // Jika latar belakang terang, teks menjadi gelap, dan sebaliknya
}