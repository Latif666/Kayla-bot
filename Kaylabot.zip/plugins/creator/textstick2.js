import { createCanvas, registerFont } from 'canvas';
import fs from 'fs';
import { sticker } from '../../lib/sticker.js';

// Menggunakan font yang diinginkan
registerFont('src/font/212BabyGirl.otf', { family: '212BabyGirl' });

let handler = async (m, { text, conn }) => {
  // Ukuran dan pembuatan kanvas
  const canvas = createCanvas(1000, 1000);
  const context = canvas.getContext('2d');

  // Menggambar teks tanpa warna dan background
  context.textAlign = 'center';
  context.textBaseline = 'middle';

  // Menghitung jumlah baris teks
  const lines = text.split('\n');
  const numLines = lines.length;

  // Ukuran font yang dinamis
  let fontSize = 400;
  do {
    context.font = `${fontSize}px 212BabyGirl`;
    fontSize--;
  } while (
    context.measureText(text).width > canvas.width - 20 ||
    getTextHeight(lines, context) > canvas.height - 20
  );

  // Menempatkan teks ke tengah
  const offsetY = (canvas.height - getTextHeight(lines, context)) / 2;

  // Menggambar teks dengan border hitam dan teks putih
  context.lineWidth = 20;
  context.strokeStyle = 'black';
  context.fillStyle = 'white';

  lines.forEach((line, index) => {
    const y = offsetY + (index + 0.5) * fontSize;
    context.strokeText(line, canvas.width / 2, y);
    context.fillText(line, canvas.width / 2, y);
  });

  // Simpan gambar
  const buffer = canvas.toBuffer('image/png');
  let stiker = await sticker(buffer, false, global.packname, global.author);
  if (stiker) return conn.sendFile(m.chat, stiker, 'output.png', '', m);
  newReply('Gambar berhasil dibuat!');
};

handler.help = ['textstick2'];
handler.tags = ['sticker','creator'];
handler.command = /^(textstick2)$/i;

export default handler;

// Fungsi untuk menghitung tinggi teks
function getTextHeight(lines, context) {
  const totalHeight = lines.length * parseInt(context.font);
  const totalSpacing = Math.max(0, lines.length - 1) * 10; // Spasi antar baris
  return totalHeight + totalSpacing;
}