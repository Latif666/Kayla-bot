import { createCanvas, loadImage } from 'canvas';
import { sticker } from '../../lib/sticker.js';

let handler = async (m, { conn, text }) => {
  let img, who;

  // Cek apakah ada pesan yang di-reply
  if (m.quoted && m.quoted.mimetype.includes('image')) {
    img = await m.quoted.download();
    who = m.quoted.sender;
  } else if (text && text.toLowerCase() === 'bulat') {
    // Cek apakah ada gambar dengan caption "bulat"
    let msgs = await conn.loadMessages(m.chat);
    let target = msgs.find(msg => msg.mimetype.includes('image') && msg.caption?.toLowerCase() === 'bulat');

    if (target) {
      img = await target.download();
      who = target.sender;
    }
  }

  if (!img) return m.reply('Tidak ada gambar yang valid untuk diubah menjadi stiker bulat.');

  // Buat gambar bulat menggunakan canvas
  const canvas = createCanvas(2000, 2000);
  const context = canvas.getContext('2d');

  context.beginPath();
  context.arc(1000, 1000, 1000, 0, 2 * Math.PI);
  context.closePath();
  context.clip();

  const image = await loadImage(img);
  context.drawImage(image, 0, 0, 2000, 2000);

  // Simpan gambar
  const buffer = canvas.toBuffer('image/png');

  // Buat stiker dari gambar bulat
  let stiker = await sticker(buffer, false, global.packname, global.author);

  // Kirim stiker
  if (stiker) {
    return conn.sendFile(m.chat, stiker, 'output.png', '', m);
  } else {
    return m.reply('Gagal membuat stiker.');
  }
};

handler.help = ['stikerbulat'];
handler.tags = ['sticker', 'creator'];
handler.command = /^(stic?kerbulat|sb)$/i ;

export default handler;