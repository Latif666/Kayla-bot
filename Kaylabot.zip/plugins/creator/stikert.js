import { createCanvas, registerFont } from 'canvas';
import fs from 'fs';
import { sticker } from '../../lib/sticker.js';

// Menggunakan font yang diinginkan
registerFont('src/font/212BabyGirl.otf', { family: '212BabyGirl' });

let handler = async (m, { text, conn }) => {
  // Ukuran dan pembuatan kanvas
  const canvas = createCanvas(1000, 1000);
  const context = canvas.getContext('2d');

  // Warna latar belakang
  context.fillStyle = generateRandomColor();
  context.fillRect(0, 0, canvas.width, canvas.height);

  // Pengaturan teks
  const backgroundColor = generateRandomColor();
  context.fillStyle = getContrastColor(backgroundColor);
  context.textAlign = 'center';
  context.textBaseline = 'middle';

  // Menghitung jumlah baris teks
  const lines = text.split('\n');
  const numLines = lines.length;

  // Ukuran font yang dinamis
  let fontSize = 400;
  do {
    context.font = `${fontSize}px 212BabyGirl`;
    fontSize--;
  } while (
    context.measureText(text).width > canvas.width - 20 ||
    getTextHeight(lines, context) > canvas.height - 20
  );

  // Menempatkan teks ke tengah
  const offsetY = (canvas.height - getTextHeight(lines, context)) / 2;

  // Menggambar teks dengan border
  context.lineWidth = 20;
  context.strokeStyle = 'black';

  lines.forEach((line, index) => {
    const y = offsetY + (index + 0.5) * fontSize;
    context.strokeText(line, canvas.width / 2, y);
    context.fillText(line, canvas.width / 2, y);
  });

  // Simpan gambar
  const buffer = canvas.toBuffer('image/png');
  let stiker = await sticker(buffer, false, global.packname, global.author);
  if (stiker) return conn.sendFile(m.chat, stiker, 'output.png', '', m);
  newReply('Gambar berhasil dibuat!');
};

handler.help = ['textstick'];
handler.tags = ['sticker','creator'];
handler.command = /^(textstick)$/i;

export default handler;

// Panggil fungsi dengan teks, warna latar belakang, dan warna teks yang diinginkan
function generateRandomColor() {
  const characters = '0123456789ABCDEF';
  let color = '#';
  for (let i = 0; i < 6; i++) {
    color += characters[Math.floor(Math.random() * 16)];
  }
  return color;
}

// Fungsi untuk menghitung tinggi teks
function getTextHeight(lines, context) {
  const totalHeight = lines.length * parseInt(context.font);
  const totalSpacing = Math.max(0, lines.length - 1) * 10; // Spasi antar baris
  return totalHeight + totalSpacing;
}

function getContrastColor(hexColor) {
  // Ambil nilai RGB dari warna latar belakang
  const r = parseInt(hexColor.slice(1, 3), 16);
  const g = parseInt(hexColor.slice(3, 5), 16);
  const b = parseInt(hexColor.slice(5, 7), 16);

  // Hitung nilai kecerahan berdasarkan formula
  const brightness = (r * 299 + g * 587 + b * 114) / 1000;

  // Tentukan warna teks berdasarkan kecerahan
  return brightness > 128 ? '#000000' : '#FFFFFF'; // Jika latar belakang terang, teks menjadi gelap, dan sebaliknya
}