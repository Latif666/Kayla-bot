import fetch from 'node-fetch'
let handler = async (m, { text, usedPrefix,  command }) => {
    if (!text) throw `Mau Nanya Apa???\n*Contoh ${usedPrefix}${command} buat cerita lucu*`
try {
let result = await fetch(`https://skizo.tech/api/openai?text=${text}&apikey=${api.skizo}`)
const gpt = result.result
m.reply(gpt)
} catch (err) {
console.log(err)
m.reply('Terjadi Kesalahan')
}}
handler.help = ['ai', 'openai']
handler.tags = ['main']
handler.command = /^(ai|la|openai)$/i
export default handler